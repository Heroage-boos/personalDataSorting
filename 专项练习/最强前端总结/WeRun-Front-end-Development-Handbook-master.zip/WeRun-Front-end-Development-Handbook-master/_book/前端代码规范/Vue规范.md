#  Vue 规范

Vue 官网上提供了风格参考指南，在使用 vue 进行项目开发时，我们应该参考这个风格指南来规范我们的代码。

> [Vue风格指南](https://cn.vuejs.org/v2/style-guide/)